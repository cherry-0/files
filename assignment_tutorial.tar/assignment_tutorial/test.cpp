#include <iostream>
#include <unistd.h>
#include "scheduler.h"
using namespace std;


int main(){
	queue trace, res[3];
	Node_t *curr;
	int n_proc = 15;

	// Trace example.
	trace.enqueue(0, 13, 1);
	trace.enqueue(1, 3, 3);
	trace.enqueue(2, 7, 4);

	// Make a random process trace.
	//generate_trace(trace, n_proc);
	
	// Display the processing results
	for(int i=0; i<3; i++){
		if(i==0) FCFS(trace, res[i]);
		else if(i==1) SRTF(trace, res[i]);
		else RR(trace, res[i]);
		cout.setf(ios::left);
		cout << setfill('-') << setw(75) << "" << setfill(' ') << endl;
		cout << setw(15) << "  Process ID" << setw(15) << "  Arrival Time" << setw(15) << "   Burst Time" << setw(15) << "Completion TIme";
		cout << setw(15) << "  Waiting Time" << endl;
		cout << setfill('-') << setw(75) << "" << setfill(' ') << endl;
		curr = res[i].head();
		double avg_wait = 0.0;
		while(curr != nullptr){
			cout << setw(6) << "" << "P" << setw(8) << curr->proc_id << setw(7) << "" << setw(8) << curr->avl_time;
			cout << setw(7) << "" << setw(8) << curr->bur_time << setw(7) << "" << setw(8) << curr->comp_time;
			cout << setw(7) << "" << setw(8) << curr->wait_time << endl;
			avg_wait += curr->wait_time;
			curr = curr->next;
		}
		cout << setfill('-') << setw(75) << "" << setfill(' ') << endl;
		cout << "Average Waiting Time: " << avg_wait/res[i].q_length() << endl;
	}
	
	return 0;
}
