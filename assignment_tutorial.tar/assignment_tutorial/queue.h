#include <iostream>
#include <iomanip>
using namespace std;

struct Node_t {
	int proc_id;     // Process ID.
	int avl_time;    // Arrival time of the process.
	int bur_time;    // Burst time of the process.
	int wait_time;   // Waiting time of the process.
	int comp_time;   // Completion time of the process.
	int re_time;     // Remaining time of the process.
	Node_t *next, *prev;
};

class queue {
	public:
		Node_t* front;
		queue() {
			// Constructor.
			this->front = nullptr;
		}

		void free_queue(Node_t* f) {
			if(f->next != nullptr) free_queue(f->next);
			delete f;
		}
	
		~queue() {
			// Destructor.
			if(front != nullptr) free_queue(front);
		}
	
		bool is_empty() {
			// Check the queue is empty.
			if(front==nullptr) return true;
			else return false;
		}
	
		void enqueue(int avl_time, int bur_time, int proc_id) {
			// Allocate a memory to the process and Push it to the end of queue
			Node_t *curr = front;
			Node_t *ret = new Node_t({proc_id, avl_time, bur_time, -1, -1, bur_time, nullptr, nullptr});
			if(front == nullptr) front = ret;
			else{
				while((curr->avl_time <= avl_time) && (curr->next != nullptr)) curr = curr->next;

				if((curr->next == nullptr) && (curr->avl_time <= avl_time)){
					curr->next = ret;
					ret->prev = curr;
				}
				else{
					if(curr->prev == nullptr) front = ret;
					else curr->prev->next = ret;
					ret->prev = curr->prev;
					ret->next = curr;
					curr->prev = ret;
				}
			}
		}
	
		void enqueue_FCFS(Node_t* proc, int p_id) {
			// Push a new process to the end of queue
			Node_t *curr = front;
			Node_t *ret = new Node_t({p_id, proc->avl_time, proc->bur_time, 0, -1, proc->bur_time, nullptr, nullptr});
			if(front == nullptr) front = ret;
			else{
				while(curr->next != nullptr) curr = curr->next;
				curr->next = ret;
				ret->prev = curr;
			}
		}

		void enqueue_SRT(Node_t* proc, int p_id) {
			// Push a new process to the queue according to SRT (Shortest Remaining Time) algorithm.
			Node_t *curr = front;
			Node_t *ret = new Node_t({p_id, proc->avl_time, proc->bur_time, 0, -1, proc->bur_time, nullptr, nullptr});
			if(front == nullptr) front = ret;
			else{
				while((curr->re_time <= proc->re_time) && (curr->next != nullptr)) curr = curr->next;

				if((curr->next == nullptr) && (curr->re_time <= proc->re_time)){
					curr->next = ret;
					ret->prev = curr;
				}
				else{
					if(curr->prev == nullptr) front = ret;
					else curr->prev->next = ret;
					ret->prev = curr->prev;
					ret->next = curr;
					curr->prev = ret;
				}
			}
		}
		
		void enqueue_ordered_pid(int avl_time, int bur_time, int proc_id) {
			// Push a new process to the queue in the order of process ID.
			Node_t *curr = front;
			Node_t *ret = new Node_t({proc_id, avl_time, bur_time, -1, -1, bur_time, nullptr, nullptr});
			if(front == nullptr) front = ret;
			else{
				while((curr->proc_id <= proc_id) && (curr->next != nullptr)) curr = curr->next;

				if((curr->next == nullptr) && (curr->proc_id <= proc_id)){
					curr->next = ret;
					ret->prev = curr;
				}
				else{
					if(curr->prev == nullptr) front = ret;
					else curr->prev->next = ret;
					ret->prev = curr->prev;
					ret->next = curr;
					curr->prev = ret;
				}
			}
		}
		
		int q_length() {
			int idx = 0;
			Node_t *curr = front;
			while(curr != nullptr){
				idx++;
				curr = curr->next;
			}
			
			return idx;
		}
	
		bool dequeue() {
			// Remove the process in front of the queue and deallocation.
			if(front == nullptr) return false;
			
			Node_t *curr = front;
			front = front->next;
			if(front != nullptr) front->prev = nullptr;

			delete curr;

			return true;
		}

	
		Node_t* head() {
			// Return the process in front of the queue.
			return front;
		}
		
		void display() {
			// Display the current queue list.
			Node_t *f;
			f = this->front;
			
			int len = q_length();
			cout.setf(ios::left);
			for(int i=0; i<len; i++) cout << setw(15) << setfill('=') << "";
			cout << endl << setfill(' ');
			for(int i=0; i<len; i++){
				if(i==0 && i!=len-1) cout << "|   P" << setw(3) << f->proc_id << "(curr) ";
				else if(i==0 && i==len-1) cout << "|   P" << setw(2) << f->proc_id << "(curr) |" << endl;
				else if(i!=0 && i==len-1) cout << "|   P" << setw(9) << f->proc_id << "|" << endl;
				else cout << "|   P" << setw(10) << f->proc_id;
				f = f->next;
			}
			f = front;
			for(int i=0; i<len-1; i++) cout << setw(15) << setfill('-') << "|";
			if(len > 1) cout << setw(14) << "" << "l" << endl << setfill(' ');
			else if(len == 1) cout << "|" << setw(13) << setfill('-') << "" << "l" << endl << setfill(' ');
			for(int i=0; i<len; i++){
				if(i==len-1) cout << "| " << setw(3) << f->avl_time << "| " << setw(3) << f->re_time << "| " << setw(2) << f->wait_time << "|" << endl;
				else {
					cout << "| " << setw(3) << f->avl_time << "| " << setw(3) << f->re_time << "| " << setw(3) << f->wait_time;
					f = f->next;
				}
			}
			for(int i=0; i<len; i++) cout << setw(15) << setfill('=') << "";
			cout << endl;
		}
	
};
