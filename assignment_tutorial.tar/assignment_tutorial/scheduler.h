#include <iostream>
#include <unistd.h>
#include <time.h>
#include "queue.h"

using namespace std;

void FCFS(queue& trace, queue& res){
	queue q_proc;
	Node_t *curr, *pos = trace.head();

	cout << setfill('*') << setw(75) << "" << endl;
	cout << "*" << setfill(' ') << setw(25) << "" << "First Come First Served" << setw(25) << ""  << "*" << endl;
	cout << setfill('*') << setw(75) << "" << endl;
	
	int idx = 0, id_idx = 0, num_done = 0;
	while(pos != nullptr || !q_proc.is_empty()){

		// New process arrival
		if(pos != nullptr)
			while(idx == pos->avl_time){
				id_idx++;
				q_proc.enqueue_FCFS(pos, id_idx);
				pos = pos->next;
				if(pos == nullptr) break;
			}

		// Print current queue status
		/*
		cout.setf(ios::left);
		cout << setfill('-') << setw(16) << "" << "Time: " << setw(16) << idx << setfill(' ') << endl;
		q_proc.display();
		sleep(1);
		*/
		

		if(!q_proc.is_empty()){
			// Execution for the process in front of queue
			q_proc.head()->re_time--;
			
			// Increase waiting time for all processes in the queue.
			curr = q_proc.head()->next;
			while(curr != nullptr){
				curr->wait_time++;
				curr = curr->next;
			}

			// The process is done
			if (q_proc.head()->re_time == 0){
				num_done++;
				res.enqueue_ordered_pid(q_proc.head()->avl_time, q_proc.head()->bur_time, q_proc.head()->proc_id);
				curr = res.head();
				while(curr->proc_id != q_proc.head()->proc_id) curr = curr->next;
				curr->wait_time = q_proc.head()->wait_time;
				curr->comp_time = idx+1;
				q_proc.dequeue();
			}
		}


		idx++;
	}
}

void SRTF(queue& trace, queue& res){
	queue q_proc;
	Node_t *curr, *pos = trace.head();
	
	cout << setfill('*') << setw(75) << "" << endl;
	cout << "*" << setfill(' ') << setw(22) << "" << "Shortest Remaining Time First" << setw(22) << ""  << "*" << endl;
	cout << setfill('*') << setw(75) << "" << endl;

	int idx = 0, id_idx = 0, num_done = 0;
	while(pos != nullptr || !q_proc.is_empty()){
		

		// New process arrival
		if(pos != nullptr)
			while(idx == pos->avl_time){
				id_idx++;
				q_proc.enqueue_SRT(pos, id_idx);
				pos = pos->next;
				if(pos == nullptr) break;
			}

		// Print current queue status
		/*
		cout.setf(ios::left);
		cout << setfill('-') << setw(16) << "" << "Time: " << setw(16) << idx << setfill(' ') << endl;
		q_proc.display();
		sleep(1);
		*/
	
		if(!q_proc.is_empty()){
			// Execution for the process in front of queue
			q_proc.head()->re_time--;
			
			// Increase waiting time for all processes in the queue.
			curr = q_proc.head()->next;
			while(curr != nullptr){
				curr->wait_time++;
				curr = curr->next;
			}

			// The process is done
			if (q_proc.head()->re_time == 0){
				num_done++;
				res.enqueue_ordered_pid(q_proc.head()->avl_time, q_proc.head()->bur_time, q_proc.head()->proc_id);
				curr = res.head();
				while(curr->proc_id != q_proc.head()->proc_id) curr = curr->next;
				curr->wait_time = q_proc.head()->wait_time;
				curr->comp_time = idx+1;
				q_proc.dequeue();
			}
		}
		
		idx++;
	}
}

void RR(queue& trace, queue& res){
	queue q_proc;
	Node_t *curr, *pos = trace.head();
	int time_slice = 3;  // execution time per process for Round Robin.
	
	cout << setfill('*') << setw(75) << "" << endl;
	cout << "*" << setfill(' ') << setw(31) << "" << "Round Robin" << setw(31) << ""  << "*" << endl;
	cout << setfill('*') << setw(75) << "" << endl;

	int idx = 0, id_idx = 0, num_done = 0;
	while(pos != nullptr || !q_proc.is_empty()){

		// New process arrival
		if(pos != nullptr)
			while(idx == pos->avl_time){
				id_idx++;
				q_proc.enqueue_FCFS(pos, id_idx);
				pos = pos->next;
				if(pos == nullptr) break;
			}
		
		// Print current queue status
		cout.setf(ios::left);
		cout << setfill('-') << setw(16) << "" << "Time: " << setw(16) << idx << setfill(' ') << endl;
		q_proc.display();
		sleep(1);
		

		if(!q_proc.is_empty()){
			// Execution for the process in front of queue
			q_proc.head()->re_time--;
			
			// Increase waiting time for all processes in the queue.
			curr = q_proc.head()->next;
			while(curr != nullptr){
				curr->wait_time++;
				curr = curr->next;
			}
	
			// The process is done
			if (q_proc.head()->re_time == 0){
				num_done++;
				res.enqueue_ordered_pid(q_proc.head()->avl_time, q_proc.head()->bur_time, q_proc.head()->proc_id);
				curr = res.head();
				while(curr->proc_id != q_proc.head()->proc_id) curr = curr->next;
				curr->wait_time = q_proc.head()->wait_time;
				curr->comp_time = idx+1;
				q_proc.dequeue();
			}
			else if ((idx+1) % time_slice == 0){
				Node_t *tail = q_proc.head();
				while(tail->next != nullptr) tail = tail->next;
				curr = q_proc.front;
				tail->next = curr;
				curr->prev = tail;
				q_proc.front = curr->next;
				curr->next = nullptr;
				q_proc.front->prev = nullptr;
				
			}
		}

		idx++;
	}
}

void generate_trace(queue& trace, int num){
	srand(time(NULL));

	for(int i=0; i<num; i++)
		trace.enqueue(rand()%21, rand()%9+2, -1);
}
